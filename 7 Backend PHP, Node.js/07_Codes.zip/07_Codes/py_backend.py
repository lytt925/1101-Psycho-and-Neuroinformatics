import sys
print(str(sys.argv))
