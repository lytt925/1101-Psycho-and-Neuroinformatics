<?php
echo $_GET['callback'].'({"name": "John" , "age": 35})';
?>
