<?php
header('Access-Control-Allow-Origin: *');
echo '{"name": "John" , "age": 35}';
?>
